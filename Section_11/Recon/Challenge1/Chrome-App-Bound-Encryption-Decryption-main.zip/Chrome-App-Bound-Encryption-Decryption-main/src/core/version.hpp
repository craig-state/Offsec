// (c) Alexander 'xaitax' Hagenah
// Licensed under the MIT License. See LICENSE file in the project root for full license information.

#pragma once

namespace Core {

    // Main version string - shown in banner
    constexpr const char* VERSION = "0.20.0";

    // Full version for build identification (update for releases)
    constexpr const char* BUILD_TAG = "v0.20.0";

}
